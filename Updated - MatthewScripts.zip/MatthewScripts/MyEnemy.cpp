// Fill out your copyright notice in the Description page of Project Settings.


#include "MyEnemy.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/Engine.h"

// Sets default values
AMyEnemy::AMyEnemy()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	EnemyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	RootComponent = EnemyMesh;

	EnemyMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));
	
	Health = 100.0f;
}

// Called when the game starts or when spawned
void AMyEnemy::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMyEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

float AMyEnemy::TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	Health -= DamageAmount;

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(
			-1, 1.5f, FColor::Red,
			FString::Printf(TEXT("Enemy Hit! Damage: %.0f | Remaining Health: %.0f"), DamageAmount, Health)
		);
	}

	if (Health <= 0)
	{
		Destroy();
	}
	return DamageAmount;
}

