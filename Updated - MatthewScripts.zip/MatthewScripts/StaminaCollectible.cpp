// Fill out your copyright notice in the Description page of Project Settings.


#include "StaminaCollectible.h"

AStaminaCollectible::AStaminaCollectible()
{
	StaminaAmount = 20.f;
}

